# Arcadena — Grande Arcade

Première version web statique, pensée pour GitHub Pages.

## Fichiers
- `index.html` : accueil et mini-jeux jouables
- `manifest.webmanifest` : métadonnées d'installation PWA
- `sw.js` : cache hors connexion
- `assets/arcadena-icon.svg` : icône du site

## Publication sur GitHub Pages
1. Crée un dépôt public nommé `arcadena`.
2. Téléverse tous les fichiers et dossiers de ce projet à la racine du dépôt.
3. Dans le dépôt, ouvre **Settings → Pages**.
4. Dans **Build and deployment**, choisis **Deploy from a branch**.
5. Sélectionne `main` et `/(root)`, puis **Save**.
6. Attends quelques minutes et ouvre l'URL affichée dans cette page.

Le fichier d'accueil doit rester nommé exactement `index.html` et se trouver à la racine.

## Notes
- Les mini-jeux sont intégrés à `index.html`, pour faciliter le premier déploiement.
- L'installation PWA dépend du navigateur et de ses critères. Pour une icône installable fiable sur le plus grand nombre d'appareils, ajoute plus tard des icônes PNG 192×192 et 512×512.
- Cette version ne contient ni comptes, ni sauvegarde en ligne, ni multijoueur réseau.
